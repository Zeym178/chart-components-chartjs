<!DOCTYPE html>
<html>
<head>
    <title>Chart Components – David</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="styles/chart-themes.css">
</head>
<body>

<h1>Dashboard Charts – David</h1>

<?php
require_once "ChartComponents.php";
include "examples.php";
?>

</body>
</html>
